EROM BOX — versão 100% offline (sem Supabase, Netlify ou Sentry)

CONTEÚDO
  site/     Versão web independente. Abra site/index.html no navegador (duplo clique).
            Não precisa de servidor nem internet. Dados ficam no navegador (localStorage).
  android/  Projeto Android (WebView) com o mesmo site embutido. Sem permissão de internet.
  .github/  Workflow que compila o APK no GitHub Actions.

COMO GERAR O APK
  1. Envie esta pasta para um repositório no GitHub.
  2. Aba Actions > "Build EROM BOX Offline APK" > Run workflow.
  3. Baixe o APK em Artifacts (EROM-BOX-OFFLINE-APK).
  Ou abra a pasta "android" no Android Studio e rode assembleDebug.

IMPORTANTE
  - Não há login nem sincronização. Os dados existem só no aparelho.
  - A biblioteca antiga que estava na nuvem NÃO vem junto. Se tiver backup (.json)
    do app antigo, use Perfil > Importar backup.
  - Ao instalar este APK por cima do antigo (mesmo pacote), os dados locais do app
    antigo continuam lá. Exporte um backup antes de desinstalar.
  - Backup no Android: salvo na pasta Downloads.
