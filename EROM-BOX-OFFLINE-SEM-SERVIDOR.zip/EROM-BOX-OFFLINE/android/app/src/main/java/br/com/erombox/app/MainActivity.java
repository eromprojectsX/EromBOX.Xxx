package br.com.erombox.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** EROM BOX: interface embutida no APK, dados locais, sem permissao de internet. */
public class MainActivity extends Activity {
    private static final int FILE_REQ = 41;
    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8, 10, 15));
        getWindow().setNavigationBarColor(Color.rgb(8, 10, 15));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 10, 15));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebViewClient(new WebViewClient() {
            private boolean local(String u) {
                return u != null && (u.startsWith("file:///android_asset/site/")
                        || u.startsWith("data:") || u.startsWith("blob:") || u.equals("about:blank"));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return !local(url); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return !local(r.getUrl().toString()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (local(r.getUrl().toString())) return super.shouldInterceptRequest(v, r);
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Escolher arquivo"), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "EromAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/site/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && filePathCallback != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(r);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public class Bridge {
        /** Salva o backup JSON na pasta Downloads (ou em Android/data do app em versoes antigas). */
        @JavascriptInterface
        public void saveBackup(String filename, String content) {
            try {
                String name = (filename == null || filename.trim().isEmpty()) ? "erom-box-backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                String where;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("insert");
                    try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bytes); }
                    where = "Downloads";
                } else {
                    File dir = getExternalFilesDir(null);
                    File f = new File(dir, name);
                    try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
                    where = f.getAbsolutePath();
                }
                toast("Backup salvo em " + where + ": " + name);
            } catch (Exception e) {
                toast("Não foi possível salvar o backup.");
            }
        }
        private void toast(final String m) {
            runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show(); } });
        }
    }
}
